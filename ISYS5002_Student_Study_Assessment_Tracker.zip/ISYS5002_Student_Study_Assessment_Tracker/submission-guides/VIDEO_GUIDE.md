# Video preparation guide (maximum 5 minutes)

This is a **guide**, not a personal story to recite as a fact. Show your own face and record your own voice.

## 0:00–1:00 – Personal story

Explain, in your own words, your actual study commitments, how you previously tracked due dates, and why you chose these features. Mention one genuine problem this tool addresses.

## 1:00–2:00 – Live product demonstration

Open the terminal and run `python main.py`. Add one **fictional** assessment, display the list, update its status, enter 1.5 study hours and show the summary. Explain why local CSV storage is useful.

## 2:00–5:00 – Explain the code

Explain how `main.py` calls `tracker.py`; where CSV files are read and written; how `check_date()` validates dates; how `upcoming()` sorts pending assessments; and how `summary()` calculates a completion percentage. Point to a test in `test_tracker.py`. Describe one code change or test that you personally completed and any limitations you discovered.

Before presenting, practise responding to: Why use CSV? What is a function? What does `try/except` do? Why is `.gitignore` important? How did you use AI, and what work was yours?
