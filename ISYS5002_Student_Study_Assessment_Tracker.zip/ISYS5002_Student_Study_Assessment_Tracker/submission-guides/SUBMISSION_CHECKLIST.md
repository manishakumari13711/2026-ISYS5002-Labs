# ISYS5002 submission checklist

- [ ] Download and fill out the **official Blackboard cover-page template**, then export it to PDF (Deliverable 1).
- [ ] Adapt source code and explanation so the project reflects your real life and your own work.
- [ ] Test using `python -m unittest test_tracker.py -v` and manually explore the menu.
- [ ] Use the official private GitHub repository's `02-project` folder; do not use a public repository.
- [ ] Store real CSV data separately and do not publish personal data.
- [ ] Record real AI conversations in `ai-assistance-logs` using the official required format. Keep related code and log updates together in commits.
- [ ] Put an accurate, personalised README.md in the source folder; prepare a PDF version for Blackboard.
- [ ] Record your own MP4 video under 5 minutes showing your face, program and code explanation.
- [ ] Upload source ZIP and AI logs ZIP to Blackboard, plus the other required deliverables.
- [ ] Prepare for the live class demonstration in Weeks 13–14 and be able to explain every function.

Assignment specification says Deliverables 1–5 were due 9 October 2026; check late submission or extension arrangements.
