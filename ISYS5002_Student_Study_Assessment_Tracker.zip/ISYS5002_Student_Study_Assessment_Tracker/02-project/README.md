# Student Study & Assessment Tracker

## Why I chose this idea (personalise before submission)

This is a sample explanation, **not a statement of the student's actual experience**. Replace it with your own true story. For example, describe the real challenges you face keeping track of assessments, deadlines and study hours. Explain what information you currently write down and how this project helps you.

## What the program does

This Python 3 command-line program allows a student to add assessments, view deadlines, mark assessments as in progress or completed, record study hours, see a completion percentage, and remove entries. The data is stored locally in a CSV file so the list remains available after the program closes.

## How to run

1. Install Python 3.
2. Open the `02-project` folder in a terminal.
3. Run `python main.py` (on some computers use `python3 main.py`).
4. Choose a menu number from 1 to 8.
5. The program creates `data/my_assessments.csv` automatically when you save. Do not upload your real personal data.

To run tests: `python -m unittest test_tracker.py -v`.

## Program design

- `main.py`: text menu, user input and display.
- `tracker.py`: functions to validate, sort, save and summarise tasks.
- `test_tracker.py`: automated checks of the main functions.
- `data/`: local CSV file created while running; excluded from Git.

## Open-source acknowledgements

No third-party packages are used. The program uses Python's standard library (`csv`, `datetime`, `pathlib`, `unittest`, `tempfile`). Python website: https://www.python.org/ . See Python licence: https://docs.python.org/3/license.html . No extra `pip install` command is needed.

## Sociotechnical considerations

**1. Privacy:** The program stores records locally rather than uploading them to an online service. A student may include sensitive study information, so the `.gitignore` excludes the `data/` folder from commits. Users still need to protect and back up their local device.

**2. Accessibility and understandable errors:** The application uses a numbered menu, readable labels and clear messages for invalid dates or hours. This reduces confusion for someone who is new to command-line tools. A limitation is that screen-reader users may still benefit from further testing.

**3. Student autonomy:** Priorities are selected by the student rather than automatically assigned. The tool provides information to support decisions but does not decide how the student should study.

## Current limitations and ideas to improve

- Assessments with the same title are allowed; the user selects them by their displayed number.
- Study hours represent manually entered time, not automatically timed sessions.
- There is no email or phone notification.
- Future features might include a weekly study plan or filtering assessments by unit.

## AI assistance and student contribution

This sample code and documentation were generated with ChatGPT assistance in a conversation on 14 October 2026. **Do not claim the generated material was written independently.** Include your complete original AI conversation logs in the required format, and accurately describe the code you personally wrote, changed, tested and understood. Your instructor assesses your actual contribution.
